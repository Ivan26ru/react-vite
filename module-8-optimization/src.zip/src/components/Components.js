// import {  } from 'react';

// const slowFunction = (value) => {
//     // здесь может быть долгий и трудоемкий код
//     return value * 2;
// }
//
// const MyComponent = ({ data }) => {
//
//     console.time('start');
//     // здесь может быть долгий и трудоемкий код
//     const slowValue = slowFunction(data);
//     console.timeEnd('end');
//
//     return (
//         <div>
//             <p>Значение: {slowValue}</p>
//         </div>
//     );
// }



// Импортируем
import { memo, useMemo, useState, useCallback } from "react";
import "./styles.css";



const testFuncMemo = useMemo(() => () => (10), []);

const testFuncCallback = useCallback(() => (10), []);



testFuncMemo  testFuncCallback



const ComponentD = () => {
    return (
        <div className="component">
            <h3>Component D</h3>
        </div>
    );
};

const ComponentC = () => {
  return (
    <div className="component">
      <h3>Component C</h3>
        <ComponentD />
    </div>
  );
};

const ComponentB = memo(({testProp}) => {
  return (
    <div className="component">
      <h3>Memo Component B</h3>
        <p>{`Show testProp value: ${testProp()}`}</p>
      <ComponentC />
    </div>
  );
});

const ComponentA = () => {
  const [count, setCount] = useState(0);
  const onClick = () => setCount((currentCount) => currentCount + 1);

  // Memo и Props
  const testProp = useMemo(() => () => (10), [])

  return (
    <div className="component">
      <h3>Component A</h3>
      <p>{`State Count: ${count}`}</p>
      <button className="button" onClick={onClick}>
        Update count
      </button>
      <ComponentB testProp={testProp}/>
    </div>
  );
};

export { ComponentA };
