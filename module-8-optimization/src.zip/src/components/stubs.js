// const usePrepareUpdates = () => {
//   const updates = useRef(0);
//   useEffect(() => {
//     updates.current = updates.current + 1;
//   });
//   return updates;
// };
